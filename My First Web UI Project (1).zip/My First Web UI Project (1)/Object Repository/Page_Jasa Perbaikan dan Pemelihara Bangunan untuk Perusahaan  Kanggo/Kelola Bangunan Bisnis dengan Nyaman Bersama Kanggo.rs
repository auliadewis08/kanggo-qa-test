<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Kelola Bangunan Bisnis dengan Nyaman Bersama Kanggo</name>
   <tag></tag>
   <elementGuidId>cca86470-af29-4bf5-8258-e009207aa9e0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'Kelola Bangunan Bisnis dengan Nyaman Bersama Kanggo' or . = 'Kelola Bangunan Bisnis dengan Nyaman Bersama Kanggo')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='__next']/div/div/div/main/div/section/div[2]/h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>a2b953f8-39ce-486e-9bcb-b5537e1b3e59</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mt-10 text-3xl font-extrabold leading-normal sm:text-6xl/tight</value>
      <webElementGuid>3eb89d2a-c6da-4279-82d7-5968060e0d3b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kelola Bangunan Bisnis dengan Nyaman Bersama Kanggo</value>
      <webElementGuid>8863c347-1ed4-4c97-8b18-3b7dcc716ab3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;__next&quot;)/div[@class=&quot;jsx-381738243 __variable_873445&quot;]/div[@class=&quot;font-averta&quot;]/div[@class=&quot;flex-1&quot;]/main[@class=&quot;relative min-h-screen&quot;]/div[@class=&quot;layoutContainer&quot;]/section[@class=&quot;relative -mt-[70px] lg:-mt-[100px] flex h-[75vh] w-full overflow-hidden bg-cover bg-no-repeat py-10 [backgroundPosition:90%] sm:py-20 lg:bg-top lg:py-32&quot;]/div[@class=&quot;relative mt-8 flex w-full flex-col justify-center px-6 text-left text-white lg:w-[65%] lg:px-10 xl:px-20&quot;]/h2[@class=&quot;mt-10 text-3xl font-extrabold leading-normal sm:text-6xl/tight&quot;]</value>
      <webElementGuid>d5bcdfb0-9e1c-4953-b12a-ae32f9ee6963</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='__next']/div/div/div/main/div/section/div[2]/h2</value>
      <webElementGuid>04dc2d95-6193-451f-9dd6-73517ef25d0f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Lainnya'])[2]/following::h2[1]</value>
      <webElementGuid>ac107d4b-aecd-4e03-a50f-ed43a992daf5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Inilah Kanggo'])[2]/following::h2[1]</value>
      <webElementGuid>68591c44-22b8-414a-b863-55e01b8ff9e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pantau seluruh proyek perbaikan dalam satu web dashboard'])[1]/preceding::h2[1]</value>
      <webElementGuid>646b2548-64e0-4bd3-87f9-ced6bd7a64e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hubungi Kami'])[1]/preceding::h2[1]</value>
      <webElementGuid>7a822200-9ae3-443c-81cd-651a8874509e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Kelola Bangunan Bisnis dengan Nyaman Bersama Kanggo']/parent::*</value>
      <webElementGuid>4179354c-0b5b-42e0-8fad-93bf1b4044f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>7bf84f3b-cb57-4ac7-9221-1c71ba8ac575</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Kelola Bangunan Bisnis dengan Nyaman Bersama Kanggo' or . = 'Kelola Bangunan Bisnis dengan Nyaman Bersama Kanggo')]</value>
      <webElementGuid>09779ffc-1a8f-4175-87a4-7ab01268dbb5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
